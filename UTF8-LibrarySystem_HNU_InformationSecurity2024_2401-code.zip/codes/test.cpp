#include<iostream>
//It`s a combined program with cooperation.
//you can found this file in github: https://github.com/Moyuin-aka/LibrarySystem_HNU_InformationSecurity2024_2401
//just a test program.You can ignore it.
using namespace std;
int main(){
	cout<<"This is a test\n"<<endl;
	return 0;
}
